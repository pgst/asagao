class TopController < ApplicationController
  def index
    @message = "おはようございます！"
  end

  def about
  end
end
