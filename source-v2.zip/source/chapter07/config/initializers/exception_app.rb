# Rails.application.config.exceptions_app = ErrorsController.action(:show)
# Rails.application.config.exceptions_app = ->(env) do
#   ErrorsController.action(:show).call(env)
# end
# Rails.application.configure do
#   config.exceptions_app = self.routes
# end
